package org.melbaraka.hospital.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.melbaraka.hospital.entities.Appointment;
import org.melbaraka.hospital.entities.Doctor;

public interface AppointmentRepository extends JpaRepository<Appointment,Long> {
}
